#include "SinhVien.h"
#include "List.h"

int main()
{
    List list;
    list.inputList();
    list.sortScores();
    list.outputList();
    return 0;
}