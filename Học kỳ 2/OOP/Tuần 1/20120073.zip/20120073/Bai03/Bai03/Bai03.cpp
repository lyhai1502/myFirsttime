#include "Date.h";
int main()
{
    Date date;
    date.input();
    date.isLeapYear();
    return 0;
}