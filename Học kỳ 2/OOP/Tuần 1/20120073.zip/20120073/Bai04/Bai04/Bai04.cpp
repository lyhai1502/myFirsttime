#include "Date.h"
int main()
{
    Date date;
    date.input();
    date.nextDay();
    return 0;
}